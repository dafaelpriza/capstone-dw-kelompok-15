# Lisensi dan atribusi

Data dalam paket ini berasal dari produsen berikut. Cantumkan atribusinya di README repositori dan laporan. Basis data turunan yang diterbitkan harus memakai Open Database License (ODbL) 1.0, karena sebagian data (BNPB) berlisensi ODbL.

- **BPS WebAPI (tabel TPB)** — Ketentuan penggunaan data BPS; cantumkan "Sumber: Badan Pusat Statistik".
- **World Bank WDI (rilis terkini)** — CC BY 4.0; cantumkan "Sumber: World Bank, World Development Indicators".

Paket disusun dari gudang data penelitian DSIC-SDG, Program Studi Sains Data ITERA.
